========
 README
========

What is it?
===========

This is a demo project to explore how to implement a sliding menu like Facebook and others use.
