package com.korovyansk.android.sample.slideout;

import org.json.JSONException;
import org.json.JSONObject;

import com.korovyansk.android.slideout.SlideoutActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.Toast;

public class NotificationActivity extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.notification_layout);
		
	      Intent intent = getIntent(); 
		  Bundle extras = intent.getExtras(); 
	      String message = extras != null ? extras.getString("com.parse.Data") : "";
          JSONObject jObject;
          try {
                  jObject = new JSONObject(message);
                  Log.d("MyApp",jObject.getString("alert"));
                  
                  Toast toast = Toast.makeText(NotificationActivity.this, jObject.getString("alert"),Toast.LENGTH_LONG);
                  toast.show();
          } catch (JSONException e) {
                  e.printStackTrace();
          }
          
      	if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
//			getActionBar().hide();
		}
		findViewById(R.id.sample_button).setOnClickListener(
				new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						int width = (int) TypedValue.applyDimension(
								TypedValue.COMPLEX_UNIT_DIP, 40, getResources()
										.getDisplayMetrics());
						SlideoutActivity.prepare(NotificationActivity.this,
								R.id.inner_content, width);
						startActivity(new Intent(NotificationActivity.this,
								MenuActivity.class));
						overridePendingTransition(0, 0);
					}
				});

		
	}
}


