package com.korovyansk.android.sample.slideout;

import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.TargetApi;

import com.parse.Parse;
import com.parse.ParseAnalytics;
import com.parse.ParseException;
import com.parse.ParseInstallation;
import com.parse.ParseObject;
import com.parse.ParsePush;
import com.parse.PushService;
import com.parse.SendCallback;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import com.korovyansk.android.slideout.SlideoutActivity;

public class TopActivity extends Activity {

	static WebView webview;
	private String Url = "http://www.google.com";
	private String menuFlag;
	@TargetApi(11)
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sample);

		Parse.initialize(this, "jug5h09p3h1h8Nzuk9pPZ4sZQccYQuXcietzxdBm",
				"P0lUcNfqZQq7y3JJdN1uSGHPlq6hwfYQ0CFKNpJS");
		PushService.setDefaultPushCallback(this, NotificationActivity.class);
		ParseInstallation.getCurrentInstallation().saveInBackground();
		ParseAnalytics.trackAppOpened(getIntent());

		webview = (WebView) findViewById(R.id.webview);
		webview.setWebViewClient(new WebViewClient());

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
//			getActionBar().hide();
		}
		findViewById(R.id.sample_button).setOnClickListener(
				new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						int width = (int) TypedValue.applyDimension(
								TypedValue.COMPLEX_UNIT_DIP, 40, getResources()
										.getDisplayMetrics());
						SlideoutActivity.prepare(TopActivity.this,
								R.id.inner_content, width);
						startActivity(new Intent(TopActivity.this,
								MenuActivity.class));
						overridePendingTransition(0, 0);
						
					}
				});
		setMenuFlag("0");
		openURL(Url);
	}

	/** Opens the URL in a browser */
	private void openURL(String url) {
		webview.loadUrl(url);
		webview.requestFocus();
	}
	
	public String getMenuFlag() {
        return menuFlag;
    }

    public void setMenuFlag(String menuStr) {
        this.menuFlag = menuStr;
    }
	
}
