/** Automatically generated file. DO NOT MODIFY */
package com.korovyansk.android.slideout;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}